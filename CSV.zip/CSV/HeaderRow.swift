//
//  HeaderRow.swift
//  
//
//  Created by developer on 11/27/19.
//

import SwiftUI

struct HeaderRow: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct HeaderRow_Previews: PreviewProvider {
    static var previews: some View {
        HeaderRow()
    }
}
