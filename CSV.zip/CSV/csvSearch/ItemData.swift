//
//  ItemData.swift
//  csvSearch
//
//  Created by developer on 11/27/19.
//  Copyright © 2019 Toxicspu. All rights reserved.
//

import Foundation
import SwiftUI

struct ItemData {
    var x:Int
}
