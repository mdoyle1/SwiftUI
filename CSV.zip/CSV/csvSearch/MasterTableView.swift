//
//  MasterTableView.swift
//  csvSearch
//
//  Created by developer on 10/9/19.
//  Copyright © 2019 Toxicspu. All rights reserved.
//

import SwiftUI

struct MasterTableView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct MasterTableView_Previews: PreviewProvider {
    static var previews: some View {
        MasterTableView()
    }
}
