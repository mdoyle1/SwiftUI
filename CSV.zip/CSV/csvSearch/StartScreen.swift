//
//  StartScreen.swift
//  csvSearch
//
//  Created by developer on 10/10/19.
//  Copyright © 2019 Toxicspu. All rights reserved.
//

import SwiftUI

struct StartScreen: View {
    var body: some View {
            VStack {
                                
        }
    }
}


struct StartScreen_Previews: PreviewProvider {
    static var previews: some View {
        StartScreen()
    }
}
