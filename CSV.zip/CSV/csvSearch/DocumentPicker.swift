//
//  DocumentPicker.swift
//  csvSearch
//
//  Created by developer on 10/8/19.
//  Copyright © 2019 Toxicspu. All rights reserved.
//

import SwiftUI

struct DocumentPicker: UIDocumentPickerView {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DocumentPicker_Previews: PreviewProvider {
    static var previews: some View {
        DocumentPicker()
    }
}
